#' secondtest: A package with some basic functions.
#'
#' The package includes a sample function and
#' a sample dataset with their respective documentation.
#'
#' @docType package
#' @name secondtest
#' @author Shaila Jamal \email{jamals16@@mcmaster.ca}
NULL
